// header-loader.js — Carga el módulo header.html de forma dinámica
// Incluir este script en todas las páginas que necesiten el header.

document.addEventListener("DOMContentLoaded", function () {
  const container = document.getElementById("header-container");
  if (!container) return;

  fetch("header.html")
    .then(function (response) {
      if (!response.ok) throw new Error("No se pudo cargar header.html");
      return response.text();
    })
    .then(function (html) {
      container.innerHTML = html;

      // Marcar el enlace activo según la página actual
      const currentPage = window.location.pathname.split("/").pop() || "index.html";
      const links = container.querySelectorAll("nav.menu a");
      links.forEach(function (link) {
        if (link.getAttribute("href") === currentPage) {
          link.classList.add("active");
        }
      });
    })
    .catch(function (error) {
      console.error("Error al cargar el header:", error);
    });
});
